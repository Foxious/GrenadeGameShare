This package contains a low-detail forklift.

Just drag the prefab into your scene and arrange them as you like.

The forklift uses 2800 polygons.

Textures-sizes 1024x1024

The original FBX-file is also included in the package.

 
